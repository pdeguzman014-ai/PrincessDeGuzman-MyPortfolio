const btn = document.getElementById('menuBtn');
const nav = document.getElementById('nav');
btn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  btn.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  btn.setAttribute('aria-expanded', 'false');
}));

const links = [...nav.querySelectorAll('a')];
const io = new IntersectionObserver(entries => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      links.forEach(l => l.classList.toggle('active', l.getAttribute('href') === '#' + e.target.id));
    }
  });
}, { rootMargin: '-35% 0px -55% 0px' });
['home','about','skills','projects','quizzes','bjmp','contact'].forEach(id => io.observe(document.getElementById(id)));

document.getElementById('year').textContent = new Date().getFullYear();

const items = document.querySelectorAll('main .card, main #projects > *, main .hero > *');
items.forEach(el => el.classList.add('reveal'));
const rio = new IntersectionObserver((entries, o) => {
  entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); o.unobserve(e.target); } });
}, { threshold: .1 });
items.forEach(el => rio.observe(el));
